% This function implements the new primal-dual method to solve:
%                   min_x f(x) + g(K(x))
% where f and g are convex, and K is a given linear operator.
% In addition, f is strongly convex.
% 
% Created by Quoc Tran-Dinh and Yuzixuan Zhu, STOR, UNC-Chapel Hill.
% Email: quoctd@email.unc.edu
% Date: 03/08/2019.
%
function [xopt, output] = scvxSemiErgoAlg(fxFunc, x0, y0, param, options)

% Define operators
fxProx  = fxFunc.fxProx;
gsProx  = fxFunc.gsProx;
K_oper  = fxFunc.K_oper;
KT_oper = fxFunc.KT_oper;
FxFull  = fxFunc.FxFull;
GyFull  = fxFunc.GyFull;

% Initialize parameters
K_nrm2  = param.K_nrm2;
tau_cur = param.tau0;
rho0    = param.rho0;
C_const = (2*param.gamma - 1)/param.gamma;

% Initialize the variables
x_cur   = x0;
y_hat   = y0;
Kx_cur  = K_oper(x_cur);
x_tilde = x_cur;
x_hat   = x_cur;
Kx_hat  = Kx_cur;
r_cur   = Kx_cur;
y_bar   = y0;
KTy_bar = KT_oper(y_bar);
n_rs    = 1;

% Save the history.
output      = [];
if options.isSaveHist > 0
    output.time = zeros(options.MaxIters, 1);
    output.fx   = zeros(options.MaxIters, 1);
    output.gy   = zeros(options.MaxIters, 1);
end
fprintf('The new primal-dual method (strongly convex case) ...\n');

% The main loop.
for iter = 1:options.MaxIters
    
    % Evaluate the objective value.
    fx_val = FxFull(x_cur, Kx_cur);
    gy_val = GyFull(y_bar, KTy_bar);
    time1 = tic;
    
    % Update parameters.
    rho      = rho0/tau_cur^2;
    beta     = C_const/(rho*K_nrm2);
    eta      = (1-param.gamma)*rho;
    tau_next = tau_cur*(sqrt(tau_cur^2 + 4) - tau_cur)/2;
    
    % The primal-dual step
    y_next   = gsProx(y_hat + rho*Kx_hat, rho);
    KTy_next = KT_oper(y_next);
    x_tilde  = fxProx(x_tilde - (beta/tau_cur)*KTy_next, beta/tau_cur);
    Kx_tilde = K_oper(x_tilde);
    x_next   = fxProx(x_hat - KTy_next/(rho*K_nrm2), 1/(rho*K_nrm2));
    Kx_next  = K_oper(x_next);

    % The correction step
    r_next   = (y_hat - y_next)/rho + Kx_hat;
    y_hat    = y_hat + eta*(Kx_next - r_next - (1 - tau_cur)*(Kx_cur - r_cur));
    
    % For next iteration
    x_hat    = (1 - tau_cur)*x_next + tau_cur*x_tilde;
    Kx_hat   = (1 - tau_cur)*Kx_next + tau_cur*Kx_tilde;
    Kx_cur   = Kx_next;
    tau_cur  = tau_next;
    x_cur    = x_next;
    r_cur    = r_next;
    
    % Compute the dual step.
    y_bar    = (1 - tau_cur)*y_bar   + tau_cur*y_next;
    KTy_bar  = (1 - tau_cur)*KTy_bar + tau_cur*KTy_next;
    
    % Save the history.
    if options.isSaveHist > 0
        output.time(iter,1) = toc(time1);
        output.fx(iter, :)  = fx_val;
        output.gy(iter, :)  = gy_val;
    end
    % Print the iteration.
    if (mod(iter, options.printStep) == 0 || iter == 1 || iter == options.MaxIters) && options.verbosity >  0
        fprintf('Iter = %4d, rho = %3.2e, beta = %3.2e, F(x) = %3.4e, G(y) = %3.4e, Gap = %3.3e\n', ...
            iter, rho, beta, fx_val, gy_val, fx_val - gy_val);
    end

    % Perform fixed restarting ...
    if options.isRestart && mod(iter, 2^n_rs*options.nRestart) == 0
        n_rs = n_rs + 1;
        fprintf('Restart at %d\n', n_rs)
        tau_cur = param.tau0;
        x_hat   = x_cur;
        Kx_hat  = Kx_cur;
        y_hat   = y_bar;
    end
end

% Finalization.
xopt = x_cur;
output.yopt = y_next;

end
