function [xopt, output] = AdmmAlg(fxFunc, x0, y0, param, options)
% This function implements the ADMM method to solve
%                   min. g(x) + h(y)
%                   s.t. -x + B(y) = c
% where g and h are two convex functions.

% Define operators
gxProx  = @(y, coef) y - coef*(fxFunc.gsProx(y/coef, 1/coef));
hyProx  = fxFunc.fxProx;
B_oper  = fxFunc.K_oper;
BT_oper = fxFunc.KT_oper;
FxFull  = fxFunc.FxFull;
ny      = size(x0);

% This is the options for PCG method.
pcgopts.maxits = 20; pcgopts.tol = 1e-5;

% Initialize parameters
rho       = param.rho0;
irho      = 1.0/rho;

% Initialization phase.
y_cur   = x0;
By_cur  = B_oper(y_cur);
x_cur   = By_cur;
lbd_cur = y0;
mu_cur  = zeros(size(y_cur));
c       = zeros(size(x_cur));

% Initialize the output.
output      = [];
if options.isSaveHist > 0
    output.fx   = zeros(options.MaxIters, 1);
    output.time = zeros(options.MaxIters, 1);
end
if options.isAvgEval > 0
    x_avg       = x_cur;
    y_avg       = y_cur;
    By_avg      = By_cur;
end
fprintf('ADMM is running ...\n');

% The main loop.
for iter = 1:options.MaxIters
    time1 = tic;
    
    % Update the primal variables.
    x_next = gxProx( By_cur - c + irho*lbd_cur, irho );
    z_next = hyProx( y_cur + irho*mu_cur, irho );
    r_cur  = z_next + BT_oper(x_next + c - irho*lbd_cur) - irho*mu_cur;
    y_next = solveLinSys(ny, B_oper, BT_oper, r_cur, y_cur, pcgopts);
    
    % Update the dual variables.
    By_next  = B_oper(y_next);
    diff_By  = -x_next + By_next - c;
    diff_yz  = y_next - z_next;
    lbd_next = lbd_cur + rho*diff_By;
    mu_next  = mu_cur  + rho*diff_yz;
    
    % Re-assign the next iteration.
    y_cur   = y_next;
    By_cur  = By_next;
    lbd_cur = lbd_next;
    mu_cur  = mu_next;
    
    % Evaluate the averaging sequence.
    if options.isAvgEval > 0
        x_avg   = (iter/(iter+1))*x_avg  + (1/(iter+1))*x_cur;
        y_avg   = (iter/(iter+1))*y_avg  + (1/(iter+1))*y_cur;
        By_avg  = (iter/(iter+1))*By_avg + (1/(iter+1))*By_cur;
        output.fx_avg(iter,1) = FxFull(y_avg, By_avg);
    end
    
    % Save history if requires
    fx_val  = FxFull(y_cur, By_cur);
    if options.isSaveHist > 0
        output.time(iter,1) = toc(time1);
        output.fx(iter,1)   = fx_val;
    end
    % Print the iteration.
    if (mod(iter, options.printStep) == 0 || iter == 1 || iter == options.MaxIters) && options.verbosity > 0
        fprintf('Iter = %4d, F(x) = %3.5f\n', iter, fx_val);
    end
end
% Finalization
xopt = y_cur;

end

% Define the linear operator for PCG.
function y = LineOper(x, B, Bt, sizey)
    X = reshape(x, sizey);
    Y = X + Bt(B(X));
    y = Y(:);
end

% This function solve (I + B'*B)*x = r.
function y = solveLinSys(sizey, Boper, BToper, r_cur, y0, opts)
    A  = @( x ) LineOper(x, Boper, BToper, sizey);
    [y_vec, FLAG, RELRES, ITER] = pcg(A, r_cur(:), opts.tol, opts.maxits, [], [], y0(:));
    y  = reshape(y_vec, sizey);
end
