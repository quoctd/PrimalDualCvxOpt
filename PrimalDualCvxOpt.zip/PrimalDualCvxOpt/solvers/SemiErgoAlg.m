% This function implements the new primal-dual method to solve:
%                   min_x f(x) + g(K(x))
% where f and g are convex, and K is a given linear operator.
% 
% Created by Quoc Tran-Dinh and Yuzixuan Zhu, STOR, UNC-Chapel Hill.
% Email: quoctd@email.unc.edu
% Date: 03/08/2019.
%
function [xopt, output] = SemiErgoAlg(FxFunc, x0, y0, param, options)

% Define operators
K_oper  = FxFunc.K_oper;
KT_oper = FxFunc.KT_oper;
fxProx  = FxFunc.fxProx;
gsProx  = FxFunc.gsProx;
FxFull  = FxFunc.FxFull;
GyFull  = FxFunc.GyFull;

% Initialize variables
x_cur   = x0;
Kx_cur  = K_oper(x_cur);
x_hat   = x0;
Kx_hat  = Kx_cur;
r_cur   = Kx_cur;
y_hat   = y0;
y_bar   = y0;
KTy_bar = KT_oper(y_bar);

% Save the history.
output = [];
if options.isSaveHist > 0
    output.fx   = zeros(options.MaxIters, 1);
    output.time = zeros(options.MaxIters, 1);
end
fprintf('The New Primal-Dual Algorithm is running ...\n');

% Extract the parameters.
rho0    = param.rho0;
tau0    = param.tau0;
K_nrm2  = param.K_nrm2;
c_shift = param.c;

% Initialize the parameter.
tau_cur = tau0;
n_rs    = 1;

% The main loop of SemiErgodic Primal-Dual Algorithm.
for iter = 1:options.MaxIters
    
    % Evaluate the objective value.
    fx_val = FxFull(x_cur, Kx_cur);
    gy_val = GyFull(y_bar, KTy_bar);
    time1  = tic;
    
    % Update parameters.
    rho_cur  = rho0*c_shift/tau_cur;
    beta_cur = param.gamma/(K_nrm2*rho_cur);
    eta_cur  = (1 - param.gamma)*rho_cur;
    tau_next = tau_cur/(tau_cur/c_shift + 1);
    
    % The primal-dual step
    y_next   = gsProx(y_hat + rho_cur*Kx_hat, rho_cur);
    KTy_next = KT_oper(y_next);
    x_next   = fxProx(x_hat - beta_cur*KTy_next, beta_cur);
    Kx_next  = K_oper(x_next);
    
    % The correction step
    r_next   = (y_hat - y_next)/rho_cur + Kx_hat;
    y_hat    = y_hat + eta_cur*(Kx_next - r_next - (1 - tau_cur)*(Kx_cur - r_cur));
    
    % Update the auxiliary vectors.
    theta    = tau_next*(1 - tau_cur)/tau_cur;
    x_hat    = (1 + theta)*x_next - theta*x_cur;
    Kx_hat   = (1 + theta)*Kx_next - theta*Kx_cur;
    
    % Compute y_bar for the next round.
    y_bar    = (1 - tau_cur)*y_bar   + tau_cur*y_next;
    KTy_bar  = (1 - tau_cur)*KTy_bar + tau_cur*KTy_next;
    
    % Move to the next iteration.
    Kx_cur  = Kx_next;
    tau_cur = tau_next;
    x_cur   = x_next;
    r_cur   = r_next;
    
    % Save the history 
    if options.isSaveHist > 0
        output.time(iter,1) = toc(time1);
        output.fx(iter, :)   = fx_val;
        output.gy(iter, :)   = gy_val;
    end
    
    % Print the iteration.
    if (mod(iter, options.printStep) == 0 || iter == 1 || iter == options.MaxIters) && options.verbosity > 0
        fprintf('iter = %4d, rho = %3.3e, beta = %3.3e, tau = %3.3e, F(x) = %5.4e, G(y) = %5.4e, Gap = %3.3e\n', ...
            iter, rho_cur, beta_cur, tau_cur, fx_val, gy_val, fx_val - gy_val);
    end
    
    % Perform fixed restarting ...
    if options.isRestart && mod(iter, 2^n_rs*options.nRestart) == 0
        n_rs = n_rs + 1;
        fprintf('Restart at %d\n', n_rs)
        tau_cur = param.tau0;
        x_hat   = x_cur;
        Kx_hat  = Kx_cur;
        y_hat   = y_bar; 
    end
end

% Finalization.
xopt = x_cur;
output.yopt = y_bar;
