function [xopt, output] = NesEuclideanAlg(FxFunc, x0, y0, param, options)
%
% This function solves the composite problem of the form:
%                   min_X f(X) + g(K(X))
%

% Define operators
K_oper  = FxFunc.K_oper;
KT_oper = FxFunc.KT_oper;
fxProx  = FxFunc.fxProx;
gsProx  = FxFunc.gsProx;
FxFull  = FxFunc.FxFull;
GyFull  = FxFunc.GyFull;

% Extract the parameters.
mu     = param.mu;
L      = param.L;
x_prox = param.x_prox;
y_prox = param.y_prox;

% Initialize variables
x_cur  = x0;
x_y    = x0;
s_cur  = zeros(size(x0));
y_cur  = zeros(size(y0));

% Save the history.
output = [];
if options.isSaveHist > 0
    output.fx   = zeros(options.MaxIters, 1);
    output.time = zeros(options.MaxIters, 1);
end
fprintf('The Nesterov method with Euclidean distances ...\n');

% The main loop of Nesterov Smoothing Algorithm (Euclidean norm).
for iter = 1:options.MaxIters
    time1 = tic;
    
    % Step 1: Compute this to form gradient of f_mu.
    y_hat   = gsProx(K_oper(x_cur)/mu + y_prox, 1/mu);
    KTy_hat = KT_oper(y_hat); % Gradient at y_hat.
    
    % Step 2: Compute yk = T_D(xk).
    x_y = fxProx(x_cur - KTy_hat/L, 1/L);
    
    % Step 3: The averaging step to compute zk.
    s_cur = s_cur + (iter/2)*KTy_hat;
    x_z   = fxProx(x_prox - s_cur/L, 1/L);
    
    % Step 4: Update x_next.
    x_cur = (2/(iter + 2))*x_z + (iter/(iter + 2))*x_y;
   
    % Step 5: Compute the averaging step on the dual problem.
    tau_cur = 2*iter/(iter*(iter + 1));
    y_cur   = (1 - tau_cur)*y_cur + tau_cur*y_hat;
    
    % Evaluate the objective value
    fx_val = FxFull(x_y, K_oper(x_y));
    gy_val = GyFull(y_cur, KT_oper(y_cur));
    
    % Save the history 
    if options.isSaveHist > 0
        output.time(iter,1) = toc(time1);
        output.fx(iter, :)  = fx_val;
        output.gy(iter, :)  = gy_val;
    end
    
    % Print the iteration.
    if (mod(iter, options.printStep) == 0 || iter == 1 || iter == options.MaxIters) && options.verbosity
        fprintf('iter = %4d, F(x) = %5.6e, G(y) = %3.6e, Gap = %3.6e\n', iter, fx_val, gy_val, fx_val - gy_val);
    end
    
end

% Finalization.
xopt = x_y;
output.yopt = y_cur;
end







