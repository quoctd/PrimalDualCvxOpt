% This function implements the Chambolle-Pock method to solve:
%                   min_x f(x) + g(K(x))
% where f and g are convex, and K is a given linear operator.
% In addition, f is strongly convex.
% 
% Created by Quoc Tran-Dinh and Yuzixuan Zhu, STOR, UNC-Chapel Hill.
% Email: quoctd@email.unc.edu
% Date: 03/08/2019.
%
function [xopt, output] = scvxCpAlg(fxFunc, x0, y0, param, options)

% Define operators
K_oper  = fxFunc.K_oper;
KT_oper = fxFunc.KT_oper;
fxProx  = fxFunc.fxProx;
gsProx  = fxFunc.gsProx;
FxFull  = fxFunc.FxFull;
GyFull  = fxFunc.GyFull;

% Optional parameters.
K_nrm2  = param.K_nrm2;
rho0    = param.rho0;
rho     = rho0;
beta    = param.gamma/(K_nrm2*rho);
muf     = param.muf;

% Initialize variables
x_cur   = x0;
y_cur   = y0;
Kx_cur  = K_oper(x_cur);
Kx_bar  = Kx_cur;
KTy_cur = KT_oper(y_cur);
if options.isAvgEval 
    T      = 0;
    x_sum  = zeros(size(x_cur));
    Kx_sum = zeros(size(Kx_cur));
end

% Save the history.
output      = [];
if options.isSaveHist > 0
    output.fx   = zeros(options.MaxIters, 1);
    output.gy   = zeros(options.MaxIters, 1);
    output.time = zeros(options.MaxIters, 1);
end
fprintf('The Chambolle-Pock algorithm (strongly convex) ... \n');

% The main loop.
for iter = 1:options.MaxIters
    
    % Evaluate the objective values.
    fx_val = FxFull(x_cur, Kx_cur);
    gy_val = GyFull(y_cur, KTy_cur);
    time1 = tic;
    
    % Dual step.
    y_next   = gsProx(y_cur + rho*Kx_bar, rho);
    
    % Primal step.
    KTy_next = KT_oper(y_next);
    x_next   = fxProx(x_cur - beta*KTy_next, beta);
    Kx_next  = K_oper(x_next);
    
    % Parameter update and currection step.
    theta  = 1/sqrt(1 + 2*muf*beta);
    Kx_bar = (1 + theta)*Kx_next - theta*Kx_cur;
    
    % Compute the averaging sequence.
    if options.isAvgEval
        T      = T + rho/rho0;
        x_sum  = x_sum + x_next*rho/rho0;
        Kx_sum = Kx_sum + Kx_next*rho/rho0;
        x_avg  = x_sum/T;
        Kx_avg = Kx_sum/T;
        output.fx_avg(iter, :) = FxFull(x_avg, Kx_avg);
    end
    
    % Update the next iteration.
    y_cur   = y_next;
    x_cur   = x_next;
    Kx_cur  = Kx_next;
    KTy_cur = KTy_next;
    rho     = rho/theta;
    beta    = beta*theta;
    
    % Save history.
    if options.isSaveHist > 0
        output.time(iter,1) = toc(time1);
        output.fx(iter, :)  = fx_val;
        output.gy(iter, :)  = gy_val;
    end
    % Print the iteration.
    if (mod(iter, options.printStep) == 0 || iter == 1 || iter == options.MaxIters) && options.verbosity >  0
        fprintf('Iter = %4d, rho = %3.2e, beta = %3.2e, F(x) = %3.4e, G(y) = %3.4e, Gap = %3.3e\n', ...
            iter, rho, beta, fx_val, gy_val, fx_val - gy_val);
    end
end

% Finalization.
xopt = x_cur;
output.yopt = y_cur;
end
