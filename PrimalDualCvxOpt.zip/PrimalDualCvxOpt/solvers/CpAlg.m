% This function implements the Chambolle-Pock method to solve:
%                   min_x f(x) + g(K(x))
% where f and g are convex, and K is a given linear operator.
% 
% Created by Quoc Tran-Dinh and Yuzixuan Zhu, STOR, UNC-Chapel Hill.
% Email: quoctd@email.unc.edu
% Date: 03/08/2019.
%
function [xopt, output] = CpAlg(fxFunc, x0, y0, param, options)

% Define operators
K_oper  = fxFunc.K_oper;
KT_oper = fxFunc.KT_oper;
fxProx  = fxFunc.fxProx;
gsProx  = fxFunc.gsProx;
FxFull  = fxFunc.FxFull;
GyFull  = fxFunc.GyFull;

% Initialize parameters
K_nrm2    = param.K_nrm2;
rho0      = param.rho0;
beta0     = param.gamma/(K_nrm2*rho0);
theta     = param.theta;

% Initialize variables
x_cur   = x0;
Kx_cur  = K_oper(x_cur);
Kx_bar  = Kx_cur;
y_cur   = y0;
KTy_cur = KT_oper(y_cur);
if options.isAvgEval > 0
    x_avg = x_cur; Kx_avg = Kx_cur;
end

% Save the history.
output      = [];
if options.isSaveHist > 0
    output.fx   = zeros(options.MaxIters, 1);
    output.gy   = zeros(options.MaxIters, 1);
    output.time = zeros(options.MaxIters, 1);
end
fprintf('The Chamble-Pock method ...\n');

% The main loop.
for iter = 1:options.MaxIters
    
    % Evaluate the objective values.
    fx_val = FxFull(x_cur, Kx_cur);
    gy_val = GyFull(y_cur, KTy_cur);
    time1 = tic;
    
    % The dual step.
    y_next = gsProx(y_cur + rho0*Kx_bar, rho0);
    
    % Primal step.
    KTy_next = KT_oper(y_next);
    x_next   = fxProx(x_cur - beta0*KTy_next, beta0);
    Kx_next  = K_oper(x_next);
    Kx_bar   = Kx_next + theta*(Kx_next - Kx_cur);
    
    % Compute the averaging sequence.
    if options.isAvgEval > 0
        x_avg  = (iter*x_avg + x_next)/(iter + 1);
        Kx_avg = (iter*Kx_avg + Kx_next)/(iter + 1);
        output.fx_avg(iter, :) = FxFull(x_avg, Kx_avg);
    end
    
    % Update for the next iteration.
    x_cur   = x_next;
    Kx_cur  = Kx_next;
    y_cur   = y_next;
    KTy_cur = KTy_next;
    
    % Save the history.
    if options.isSaveHist > 0
        output.time(iter,1) = toc(time1);
        output.fx(iter, :)   = fx_val;
        output.gy(iter, :)   = gy_val;
    end
    % Print the iteration.
    if (mod(iter, options.printStep) == 0 || iter == 1 || iter == options.MaxIters) && options.verbosity
        fprintf('iter = %4d, F(x) = %5.6e, G(y) = %3.6e, Gap = %3.6e\n', ...
                iter, fx_val, gy_val, fx_val - gy_val);
    end
end

% Finalization.
xopt = x_cur;
output.yopt = y_cur;
end
