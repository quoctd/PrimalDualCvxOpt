%% Example 2: Solving the minmax game problem of the form:
%
%          min_x max_y <Kx, y> 
%          s.t. x in Simplex(p), y in Simplex(n),
%
% where K is a given pxn matrix.
% Created by Quoc Tran-Dinh and Yuzixuan Zhu, STOR, UNC-Chapel Hill.
% Email: quoctd@email.unc.edu
% Date: 03/08/2019.
%

% Generate the input data. 
m    = 5000; 
p    = 2000; 
d    = 0.1;

K    = 2*rand(m, p) - 1;
mask = rand(m, p);
mask = mask <= d;
K    = K.*mask;
nrmK = norm(K);
K    = K/nrmK;
KT   = K';
nrmK = norm(K);

%% Operators.
FxFunc.fxProx  = @(x, coef) projSimplex(x);
FxFunc.gsProx  = @(y, coef) projSimplex(y);
FxFunc.K_oper  = @(x)       K*x;
FxFunc.KT_oper = @(y)       KT*y;
FxFunc.fxFunc  = @(y)       max(max(y), 0);
FxFunc.gsEval  = @(x)       -max(max(-x), 0);
FxFunc.FxFull  = @(x, Kx)   max(Kx); %max(max(Kx), 0);
FxFunc.GyFull  = @(y, KTy)  min(KTy); %-max(max(-KTy), 0);

% Initialize parameters
options.MaxIters = 2000;
options.printStep = 500;
options.isSaveHist = 1;
options.verbosity  = 1;
options.isRestart  = 0;
options.nRestart   = 0;
options.isAvgEval  = 1;

% Other parameters.
param.K_nrm2 = nrmK^2;
param.gamma  = 0.5;
param.rho0   = 1.0/nrmK;
param.tau0   = 1;
param.c      = 1;

%% Parameter for Nesterov methods.
nes_param.K_nrm2   = nrmK^2;
nes_param.epsilon  = 1e-3;  
nes_param.mu       = nes_param.epsilon/(2*(1 - 1/m));
nes_param.L        = param.K_nrm2/nes_param.mu;
nes_param.MaxIters = round(4*sqrt(nes_param.K_nrm2)*sqrt((1-1/p)*(1-1/m))/nes_param.epsilon);
nes_param.x_prox   = ones(p, 1)/p;
nes_param.y_prox   = ones(m, 1)/m;
fprintf('The number of iterations: %4d\n', nes_param.MaxIters);

% Generate an initial point.
x0 = (1/p)*ones(p, 1);
y0 = (1/m)*ones(m, 1);

%% Run all the codes.
%% Run SemiErgo, c = 1 ...
fprintf('\nRunning SemiErgoC1, c = 1 ...\n');
param.c      = 1;
options.MaxIters = nes_param.MaxIters;
options.isRestart  = 0;
[xoptSEA1, outputSEA1] = SemiErgoAlg(FxFunc, x0, y0, param, options);

%% Run SemiErgo, c > 1 ...
fprintf('\nRunning SemiErgoC1, c > 1, ...\n');
options.isRestart  = 0;
param.c      = 2;
[xoptSEA2, outputSEA2] = SemiErgoAlg(FxFunc, x0, y0, param, options);

%% Run SemiErgo, c > 1 and restart ...
fprintf('\nRunning SemiErgoC1, c > 1 and restart ...\n');
options.isRestart  = 1;
options.nRestart   = 100;
param.c            = 2;
[xoptSEA3, outputSEA3] = SemiErgoAlg(FxFunc, x0, y0, param, options);

%% Run Nesterov, Euclidean ...
fprintf('\nRunning Nesterov, Euclidian...\n');
[xoptNes1, outputNes1] = NesEuclideanAlg(FxFunc, x0, y0, nes_param, options);

%% Run Nesterov, Euclidean ...
fprintf('\nRunning Nesterov, Euclidian...\n');
nes_param.mu       = 5*nes_param.epsilon/(2*(1 - 1/m));
nes_param.L        = param.K_nrm2/nes_param.mu;
[xoptNes2, outputNes2] = NesEuclideanAlg(FxFunc, x0, y0, nes_param, options);

%% Run Nesterov, Euclidean ...
fprintf('\nRunning Nesterov, Euclidian...\n');
nes_param.mu       = 0.2*nes_param.epsilon/(2*(1 - 1/m));
nes_param.L        = param.K_nrm2/nes_param.mu;
[xoptNes3, outputNes3] = NesEuclideanAlg(FxFunc, x0, y0, nes_param, options);

%% Plot figures.
% Preparation ...
objValsP = [outputSEA1.fx, outputSEA2.fx, outputSEA3.fx, outputNes1.fx, outputNes2.fx, outputNes3.fx];
objValsD = [outputSEA1.gy, outputSEA2.gy, outputSEA3.gy, outputNes1.gy, outputNes2.gy, outputNes3.gy];
GAP      = objValsP - objValsD;
g0       = max(GAP(:));
onevsk   =  abs(g0)./[1:length(outputSEA1.gy)]';
objValsG = [onevsk, objValsP - objValsD];

% Plot ...
h = figure(1);
semilogy(objValsG(:,1), 'k:', 'Marker', 'o', 'LineWidth', 2, 'MarkerSize', 6); hold on;
semilogy(objValsG(:,2), 'r--', 'Marker', 's', 'LineWidth', 2, 'MarkerSize', 6); hold on;
semilogy(objValsG(:,3), 'b-.', 'Marker', '^', 'LineWidth', 2, 'MarkerSize', 6); hold on;
semilogy(objValsG(:,4), 'c-', 'Marker', 'h', 'LineWidth', 2, 'MarkerSize', 6); hold on;
semilogy(objValsG(:,5), 'k--', 'Marker', 'p', 'LineWidth', 2, 'MarkerSize', 6); hold on;
semilogy(objValsG(:,6), 'm-.', 'Marker', 'd', 'LineWidth', 2, 'MarkerSize', 6); hold on;
semilogy(objValsG(:,7), 'g-', 'Marker', 's', 'LineWidth', 2, 'MarkerSize', 6); hold off;
xlabel('Number of Iterations', 'Interpreter', 'Latex', 'FontSize', 14);
ylabel('Absolute gap value $F(x^k)+G(y^k)$-in logscale', 'Interpreter', 'Latex', 'FontSize', 14);
MarkerPlus(10);
grid on;
str_le = {'$\frac{1}{k}$-convergence rate', 'Algorithm 1 ($c=1$)', ...
          'Algorithm 1 $(c=2$)', 'Algorithm 1 ($c=2$, restarting)', ...
          'Nesterov smoothing', 'Nesterov smoothing ($5\mu$)', ...
          'Nesterov smoothing ($0.2\mu$)'};
legend(str_le , 'Interpreter', 'Latex', 'FontSize', 12);

%% End ...
