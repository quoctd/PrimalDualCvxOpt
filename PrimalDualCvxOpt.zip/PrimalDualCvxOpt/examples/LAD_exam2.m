% The least absolute derivation problem (LAD) with elastic-net:
%
%       min_x LAMBDA*||x||_1 + 0.5*mu_f|x|^2 + ||B*x - c||_1.
%
% Created by Quoc Tran-Dinh and Yuzixuan Zhu, STOR, UNC-Chapel Hill.
% Email: quoctd@email.unc.edu
% Date: 03/08/2019.

%% Generate the input data.
scale           = 2; % Change this to get different problem size
p               = scale*1000;
m               = scale*320; 
s               = scale*100;

% Generate matrix B.
cor_tau = 0.5;
if cor_tau > 0
	var0 = (1 - cor_tau)^2 / (1 - cor_tau^2); %initial variance
	K = zeros(m, p);
	K(:,1) = sqrt(var0)*randn(m, 1);
	for kk = 2:p
        K(:,kk) = cor_tau*K(:,kk-1) + (1 - cor_tau)*(randn(m,1));
	end
else
    K   = randn(m, p);
end

% Normalize the data.
K  = bsxfun(@rdivide, K, sqrt(sum(K.*K, 2)));
KT = K';

% Generate vector c.
x_org    = zeros(p, 1);
T        = randperm(p, s);
x_org(T) = randn(s, 1);
noise    = sprandn(m, 1, 0.1);
sig      = 0.01;   %0.01 or 0.001;
c        = K*x_org + sig*noise;
c_norm   = norm(c);

% others
LAMBDA = 0.05;	% regularizor
MU     = 0.1;   % add strong convexity for elastic net.

%% Operators.
soft_threshold    = @(x, coef) sign(x).*max(abs(x) - coef, 0);
FxFunc.fxFunc     = @(x)       LAMBDA*norm(x, 1) + 0.5*MU*x'*x;
FxFunc.fxProx     = @(x, coef) soft_threshold( (1/(coef*MU + 1))*x, LAMBDA*coef/(coef*MU + 1));
FxFunc.gyFunc     = @(y)       norm(y - c, 1);
FxFunc.gsProx     = @(y, coef) y - coef*(soft_threshold(y/coef - c, 1/coef) + c);
FxFunc.K_oper     = @(x)       K*x;
FxFunc.KT_oper    = @(y)       KT*y;
FxFunc.FxFull     = @(x, y)    FxFunc.fxFunc(x) + FxFunc.gyFunc(y);
FxFunc.GyFull     = @(x, y)    0;

%% Call the CVX-Mosek solver.
if exist('cvx_begin.m')
    time_cvx = tic;
    cvx_solver mosek; % If mosek is not installed, comment this line
    %cvx_precision high; 
    cvx_begin
        variable x_cvx(p);
        variable r_cvx(m);
        dual variable y_cvx;
        minimize( LAMBDA*norm(x_cvx, 1) + 0.5*MU*x_cvx'*x_cvx + norm(r_cvx, 1) );
        subject to
            y_cvx: r_cvx == K*x_cvx - c;
    cvx_end
    time_cvx  = toc(time_cvx);
    fx_cvx    = LAMBDA*norm(x_cvx, 1) + norm(K*x_cvx - c, 1) + 0.5*MU*x_cvx'*x_cvx;
else
    fx_cvx = 0; time_cvx = 0; nrm_y_cvx = nan;
end

%% Initializations
% Initial points.
x0 = zeros(p, 1);
y0 = zeros(m, 1);

% Initialize parameters
options.MaxIters     = 3000;
options.printStep    = 100;
options.verbosity    = 1;
options.isSaveHist   = 1;
options.isRestart    = 0;
options.nRestart     = 50;

% Define the parameters for runs.
param.muf            = MU;
normK                = norm(K);
param.K_nrm2         = normK^2;
GAMMA                = 0.999;
GAMMA_CP             = 0.99;
RHO0                 = sqrt(GAMMA/(1 - GAMMA))*norm(y0 - y_cvx)/(normK*norm(x0 - x_cvx));
C_const              = (2*GAMMA - 1)/GAMMA;

%% Run all the algorithms.
%
%% scvxSemiErgo
fprintf('\nRunning scvx-SemiErgo ...\n');
options.isRestart = 0;
param.tau0  = 1;
param.gamma = GAMMA;
param.rho0  = C_const*MU/(2*param.K_nrm2);
[xoptSEA1, outputSEA1] = scvxSemiErgoAlg(FxFunc, x0, y0, param, options);

%% scvxSemiErgo
fprintf('\nRunning scvxSemiErgo: 5*rho0 ...\n');
options.isRestart = 0;
param.tau0  = 1;
param.gamma = GAMMA;
param.rho0  = 5*C_const*MU/(2*param.K_nrm2);
[xoptSEA1b, outputSEA1b] = scvxSemiErgoAlg(FxFunc, x0, y0, param, options);

%% scvxSemiErgo
fprintf('\nRunning scvxSemiErgo: Restarting  ...\n');
options.isRestart = 1;
options.nRestart  = 200;
param.tau0  = 1;
param.gamma = GAMMA;
param.rho0  = 5*C_const*MU/(2*param.K_nrm2);
[xoptSEA2, outputSEA2] = scvxSemiErgoAlg(FxFunc, x0, y0, param, options);

%% Chambole-Pock's method (rho = 1/norm(K)) ...
fprintf('\nRunning scvx Chambolle-Pock method (Theoretical step-size) ...\n');
options.isAvgEval = 1;
param.gamma = GAMMA_CP;
param.rho0  = 1/normK;
param.theta = 1;
[xoptCp, outputCp] = scvxCpAlg(FxFunc, x0, y0, param, options);

%% Chambole-Pock's method (rho = 5/norm(K)) ...
fprintf('\nRunning scvx Chambolle-Pock method with 5*rho0 ...\n');
options.isAvgEval = 1;
param.gamma = GAMMA_CP;
param.rho0  = 5/normK;
param.theta = 1;
[xoptCp2, outputCp2] = scvxCpAlg(FxFunc, x0, y0, param, options);

%% Chambole-Pock's method (rho = 0.2/norm(K)) ...
fprintf('\nRunning Chambolle-Pock method with 0.2*rho0 ...\n');
options.isAvgEval = 1;
param.gamma = GAMMA_CP;
param.rho0  = 1/normK/5;
param.theta = 1;
[xoptCp3, outputCp3] = scvxCpAlg(FxFunc, x0, y0, param, options);

%% Plotting ...
fx_cvx1  = fx_cvx - 1e-6;
objVals = [outputSEA1.fx, outputSEA1b.fx, outputSEA2.fx, outputCp.fx, ...
           outputCp.fx_avg, outputCp2.fx, outputCp2.fx_avg, ...
           outputCp3.fx, outputCp3.fx_avg];
objVals = (objVals - fx_cvx1)/max(abs(fx_cvx1), 0);

semilogy(objVals);
legend('A1', 'A1-5', 'A1-rs', 'CP', 'CP-avg', 'CP/5', 'CP/5-avg', '5*CP', '5*CP-avg');
