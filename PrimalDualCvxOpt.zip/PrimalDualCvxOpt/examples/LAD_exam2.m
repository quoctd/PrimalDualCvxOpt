% The least absolute derivation problem (LAD) with elastic-net:
%
%       min_x LAMBDA*||x||_1 + 0.5*mu_f|x|^2 + ||B*x - c||_1.
%
% Created by Quoc Tran-Dinh and Yuzixuan Zhu, STOR, UNC-Chapel Hill.
% Email: quoctd@email.unc.edu
% Date: 03/08/2019.

%% Generate the input data.
scale           = 2; % Change this to get different problem size
p               = scale*1000;
m               = scale*320; 
s               = scale*100;

% Generate matrix B.
cor_tau = 0.5;
if cor_tau > 0
	var0 = (1 - cor_tau)^2 / (1 - cor_tau^2); %initial variance
	K = zeros(m, p);
	K(:,1) = sqrt(var0)*randn(m, 1);
	for kk = 2:p
        K(:,kk) = cor_tau*K(:,kk-1) + (1 - cor_tau)*(randn(m,1));
	end
else
    K   = randn(m, p);
end

% Normalize the data.
K  = bsxfun(@rdivide, K, sqrt(sum(K.*K, 2)));
KT = K';

% Generate vector c.
x_org    = zeros(p, 1);
T        = randperm(p, s);
x_org(T) = randn(s, 1);
noise    = sprandn(m, 1, 0.1);
sig      = 0.01;   %0.01 or 0.001;
c        = K*x_org + sig*noise;
c_norm   = norm(c);

% others
LAMBDA = 0.05;	% regularizor
MU     = 0.1;   % add strong convexity for elastic net.

%% Operators.
soft_threshold    = @(x, coef) sign(x).*max(abs(x) - coef, 0);
FxFunc.fxFunc     = @(x)       LAMBDA*norm(x, 1) + 0.5*MU*x'*x;
FxFunc.fxProx     = @(x, coef) soft_threshold( (1/(coef*MU + 1))*x, LAMBDA*coef/(coef*MU + 1));
FxFunc.gyFunc     = @(y)       norm(y - c, 1);
FxFunc.gsProx     = @(y, coef) y - coef*(soft_threshold(y/coef - c, 1/coef) + c);
FxFunc.K_oper     = @(x)       K*x;
FxFunc.KT_oper    = @(y)       KT*y;
FxFunc.FxFull     = @(x, y)    FxFunc.fxFunc(x) + FxFunc.gyFunc(y);
FxFunc.GyFull     = @(x, y)    0;

%% Call the CVX-Mosek solver.
if exist('cvx_begin.m')
    time_cvx = tic;
    cvx_solver mosek; % If mosek is not installed, comment this line
    cvx_precision high; 
    cvx_begin
        variable x_cvx(p);
        variable r_cvx(m);
        dual variable y_cvx;
        minimize( LAMBDA*norm(x_cvx, 1) + 0.5*MU*x_cvx'*x_cvx + norm(r_cvx, 1) );
        subject to
            y_cvx: r_cvx == K*x_cvx - c;
    cvx_end
    time_cvx  = toc(time_cvx);
    fx_cvx    = LAMBDA*norm(x_cvx, 1) + norm(K*x_cvx - c, 1) + 0.5*MU*x_cvx'*x_cvx;
else
    fx_cvx = 0; time_cvx = 0; nrm_y_cvx = nan;
end

%% Initializations
% Initial points.
x0 = zeros(p, 1);
y0 = zeros(m, 1);

% Initialize parameters
options.MaxIters     = 3000;
options.printStep    = 100;
options.verbosity    = 1;
options.isSaveHist   = 1;
options.isRestart    = 0;
options.nRestart     = 50;

% Define the parameters for runs.
param.muf            = MU;
normK                = norm(K);
param.K_nrm2         = normK^2;
GAMMA                = 0.75;
GAMMA_CP             = 0.99;
RHO0                 = sqrt(GAMMA/(1 - GAMMA))*norm(y0 - y_cvx)/(normK*norm(x0 - x_cvx));
C_const              = (2*GAMMA - 1)/GAMMA;

%% Run all the algorithms.
%
%% scvxSemiErgo with theoretical step-size
fprintf('\nRunning scvx-SemiErgo ...\n');
options.isRestart = 0;
param.tau0        = 1;
param.gamma       = GAMMA;
param.rho0        = C_const*MU/(2*param.K_nrm2);
param.c_shift     = 2;
[xoptSEA1, outputSEA1] = scvxSemiErgoAlg(FxFunc, x0, y0, param, options);

%% scvxSemiErgo with 10 times of the theoretical stepsize
fprintf('\nRunning scvxSemiErgo: 5*rho0 ...\n');
options.isRestart = 0;
param.tau0        = 1;
param.gamma       = GAMMA;
param.c_shift     = 2;
param.rho0        = 5*C_const*MU/(2*param.K_nrm2);
[xoptSEA1b, outputSEA1b] = scvxSemiErgoAlg(FxFunc, x0, y0, param, options);

%% scvxSemiErgo with c > 2
fprintf('\nRunning scvxSemiErgo with c > 2 ...\n');
options.isRestart = 0;
param.tau0        = 1;
param.gamma       = GAMMA;
c0                = 4;
param.c_shift     = c0;
param.rho0        = (c0-1)/(c0*(2*c0-1))*C_const*MU/(param.K_nrm2);
[xoptSEA1c, outputSEA1c] = scvxSemiErgoAlg(FxFunc, x0, y0, param, options);

%% scvxSemiErgo with restarting.
fprintf('\nRunning scvxSemiErgo: Restarting  ...\n');
options.isRestart = 1;
options.nRestart  = 50;
param.tau0        = 1;
param.gamma       = GAMMA;
param.c_shift     = 2;
param.rho0        = 5*C_const*MU/(2*param.K_nrm2);
[xoptSEA2, outputSEA2] = scvxSemiErgoAlg(FxFunc, x0, y0, param, options);

%% scvxSemiErgo with restarting with c = 4.
fprintf('\nRunning scvxSemiErgo: Restarting  with (c = 4) ...\n');
options.isRestart = 1;
options.nRestart  = 50;
param.tau0        = 1;
param.gamma       = GAMMA;
c0                = 4;
param.c_shift     = c0;
param.rho0        = (c0-1)/(c0*(2*c0-1))*C_const*MU/(param.K_nrm2);
[xoptSEA2b, outputSEA2b] = scvxSemiErgoAlg(FxFunc, x0, y0, param, options);

%% Chambole-Pock's method (rho = norm(y0 - y_cvx)/(normK*norm(x0 - x_cvx))) ...
fprintf('\nRunning scvx Chambolle-Pock method (Theoretical step-size) ...\n');
options.isAvgEval = 1;
param.gamma = GAMMA_CP;
param.rho0  = norm(y0 - y_cvx)/(normK*norm(x0 - x_cvx));
param.theta = 1;
[xoptCp, outputCp] = scvxCpAlg(FxFunc, x0, y0, param, options);

%% Chambole-Pock's method (rho = 10*norm(y0 - y_cvx)/(normK*norm(x0 - x_cvx))) ...
fprintf('\nRunning scvx Chambolle-Pock method with 10*rho0 ...\n');
options.isAvgEval = 1;
param.gamma = GAMMA_CP;
param.rho0  = 10*norm(y0 - y_cvx)/(normK*norm(x0 - x_cvx));
param.theta = 1;
[xoptCp2, outputCp2] = scvxCpAlg(FxFunc, x0, y0, param, options);

%% Chambole-Pock's method (rho = 0.2*norm(y0 - y_cvx)/(normK*norm(x0 - x_cvx))) ...
fprintf('\nRunning Chambolle-Pock method with 0.2*rho0 ...\n');
options.isAvgEval = 1;
param.gamma = GAMMA_CP;
param.rho0  = 0.2*norm(y0 - y_cvx)/(normK*norm(x0 - x_cvx));
param.theta = 1;
[xoptCp3, outputCp3] = scvxCpAlg(FxFunc, x0, y0, param, options);

%% Plotting ...
% Last iterates
objVals = [outputSEA1.fx, outputSEA1b.fx, outputSEA1c.fx, outputSEA2.fx, outputSEA2b.fx, ...
           outputCp.fx, outputCp2.fx, outputCp3.fx];
fx_cvx1  = min([fx_cvx; objVals(:)]);
objVals = (objVals - fx_cvx1)/max(abs(fx_cvx1), 0);

% Averaging
avg_objVals = [outputSEA1.fx, outputSEA1b.fx, outputSEA1c.fx, ...
               outputCp.fx_avg, outputCp2.fx_avg, outputCp3.fx_avg];
avg_objVals = (avg_objVals - fx_cvx1)/max(abs(fx_cvx1), 0);

% Plot the averaging sequences ...
figure(1);
h1 = subplot(1,2,1);
semilogy(avg_objVals(:,1), 'b--', 'LineWidth', 2, 'Marker', 'o', 'MarkerSize', 6); hold on;
semilogy(avg_objVals(:,2), 'r-.', 'LineWidth', 2, 'Marker', 's', 'MarkerSize', 6); hold on;
semilogy(avg_objVals(:,3), 'k-', 'LineWidth', 2, 'Marker', '*', 'MarkerSize', 6); hold on;
semilogy(avg_objVals(:,4), 'm:', 'LineWidth', 2, 'Marker', 'p', 'MarkerSize', 6); hold on;
semilogy(avg_objVals(:,5), 'c--', 'LineWidth', 2, 'Marker', 'd', 'MarkerSize', 6); hold on;
semilogy(avg_objVals(:,6), '-.', 'LineWidth', 2, 'Marker', 'v', 'MarkerSize', 6, 'Color', [0.5 0.5 0.5]); hold off;
str_legend1 = {'Algorithm 2', 'Algorithm 2 ($5\rho_0$)', ...
               'Algorithm 2 ($c=4$)', 'CP (averaging)', ...
               'CP (averging, $\rho_0/5$)', 'CP (averging, $10\rho_0$)'};
legend(h1, str_legend1, 'Interpreter', 'Latex', 'FontSize', 12);
xlabel('Number of Iterations', 'Interpreter', 'Latex', 'FontSize', 14);
ylabel('$\frac{F(x^k) - F^{\star}}{\vert F^{\star}\vert}$-in logscale', 'Interpreter', 'Latex', 'FontSize', 14);
MarkerPlus(10);
grid on;

% Plot the last iterate sequences ...
h2 = subplot(1,2,2);
semilogy(objVals(:,1), 'b--', 'LineWidth', 2, 'Marker', 'o', 'MarkerSize', 6); hold on;
semilogy(objVals(:,2), 'r-.', 'LineWidth', 2, 'Marker', 's', 'MarkerSize', 6); hold on;
semilogy(objVals(:,3), 'k-', 'LineWidth', 2, 'Marker', '*', 'MarkerSize', 6); hold on;
semilogy(objVals(:,4), '-.', 'LineWidth', 2, 'Marker', 'h', 'MarkerSize', 6, 'Color', [0.5 0.5 0]); hold on;
semilogy(objVals(:,5), '-', 'LineWidth', 2, 'Marker', '^', 'MarkerSize', 6, 'Color', [0.1 0.25 0.5]); hold on;
semilogy(objVals(:,6), 'm:', 'LineWidth', 2, 'Marker', 'p', 'MarkerSize', 6); hold on;
semilogy(objVals(:,7), 'c--', 'LineWidth', 2, 'Marker', 'd', 'MarkerSize', 6); hold on;
semilogy(objVals(:,8), '-.', 'LineWidth', 2, 'Marker', 'v', 'MarkerSize', 6, 'Color', [0.5 0.5 0.5]); hold off;
str_legend2 = {'Algorithm 2', 'Algorithm 2 ($5\rho_0$)', ...
              'Algorithm 2 ($c=4$)', 'Algorithm 2 (restarting)', 'Algorithm 2 (restarting, $c=4$)', ...
              'CP (last iterate)', 'CP (last iterate, $\rho_0/5$)', ...
              'CP (last iterate, $10\rho_0$)'};
legend(h2, str_legend2, 'Interpreter', 'Latex', 'FontSize', 12);
xlabel('Number of Iterations', 'Interpreter', 'Latex', 'FontSize', 14);
ylabel('$\frac{F(x^k) - F^{\star}}{\vert F^{\star}\vert}$-in logscale', 'Interpreter', 'Latex', 'FontSize', 14);
MarkerPlus(10);
grid on;

%% End ...