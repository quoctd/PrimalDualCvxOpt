function x = projSimplex(y)
% Wang, W. and Carreira-Perpin�n, M.A., 2013.
% Projection onto the probability simplex: An efficient algorithm with a
% simple proof, and an application. arXiv preprint arXiv:1309.1541.
% Dn = { x : x n-dim, 1 >= x >= 0, sum(x) = 1}

    x_sorted = sort(y, 'descend');
    x_tmp    = diag(sparse(1./(1:length(y))))*(cumsum(x_sorted) - 1);
    x        = max(y - x_tmp(find(x_sorted > x_tmp, true, 'last')), 0);
end